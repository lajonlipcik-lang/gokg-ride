import { useEffect, useRef, useState } from "react";
import "./gokg-splash.css";

interface GokgSplashProps {
  onFinish?: () => void;
  durationMs?: number;
}

/** Animated arrival mark. Only the splash screen is affected. */
export function GokgSplash({ onFinish, durationMs = 3000 }: GokgSplashProps) {
  const [leaving, setLeaving] = useState(false);
  const finishRef = useRef(onFinish);
  finishRef.current = onFinish;

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const total = reduced ? 650 : durationMs;
    const leaveTimer = window.setTimeout(() => setLeaving(true), total);
    const doneTimer = window.setTimeout(() => finishRef.current?.(), total + (reduced ? 160 : 500));
    return () => {
      window.clearTimeout(leaveTimer);
      window.clearTimeout(doneTimer);
    };
  }, [durationMs]);

  return (
    <div className={`gokg-splash${leaving ? " leaving" : ""}`} data-testid="gokg-splash" role="img" aria-label="GoKG Ride — прибытие">
      <div className="gokg-arrival-stage">
        <div className="gokg-speed-trail" aria-hidden="true" />
        <div className="gokg-arrival-mark">
          <img src="/gokg-arrival-logo.png" alt="" className="gokg-arrival-logo" draggable={false} />
        </div>
        <div className="gokg-arrival-ground" aria-hidden="true" />
      </div>
    </div>
  );
}
